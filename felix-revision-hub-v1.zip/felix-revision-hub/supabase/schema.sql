-- Run this in Supabase SQL Editor.
create table if not exists public.revision_sessions (
  id text primary key,
  title text not null,
  topic text not null default 'Development',
  date date not null default current_date,
  summary text not null,
  items text[] not null default '{}',
  status text not null default 'Published',
  created_at timestamptz not null default now()
);
alter table public.revision_sessions enable row level security;
create policy "Anyone can read published sessions" on public.revision_sessions
for select using (status = 'Published');
-- Admin accounts must have app_metadata.role = 'admin', set by a trusted project owner.
create policy "Admins can insert sessions" on public.revision_sessions
for insert to authenticated
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
create policy "Admins can update sessions" on public.revision_sessions
for update to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
create policy "Admins can delete sessions" on public.revision_sessions
for delete to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
