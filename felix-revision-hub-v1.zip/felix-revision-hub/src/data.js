export const initialSessions = [
 {id:'s1',title:'Development and Development Indicators',topic:'Development',date:'2026-11-22',summary:'Understand development, development indicators and standard of living.',items:['Development: the improvement in wealth, education and health in a country over time.','Development indicator: statistics that tell us about the development in a place.','Standard of living: refers to how comfortable people’s lives are in a country.','Development gap: the differences in standard of living for the richest and poorest people in the world.'],status:'Published'},
 {id:'s2',title:'Causes of Poverty',topic:'Development',date:'2026-11-23',summary:'Physical, economic and historic causes of poverty.',items:['Physical: relief, climate and being landlocked.','Economic: debt, corruption and trade.','Historic: colonisation and conflict.'],status:'Published'},
 {id:'s3',title:'Closing the Development Gap',topic:'Development',date:'2026-11-23',summary:'Ways of helping people and places.',items:['Aid: money, resources or expertise for emergency or long-term development.','Fair trade: ensures producers get a fair and consistent price for their product.','Investment: funding essential services and industry.','Microfinance: small loans to help groups set up a business in their community and earn income.','Debt relief: lowering or cancelling debt owed by LICs to HICs.','Appropriate technology: small-scale, low-technology solutions that the community can use.','SDGs: 17 goals set out by the UN to solve global problems.'],status:'Published'}
];
export const flashcards = [
 ['What is development?','The improvement in wealth, education and health in a country over time.'],
 ['What is a development indicator?','Statistics that tell us about the development in a place.'],
 ['What is standard of living?','How comfortable people’s lives are in a country.'],
 ['What is the development gap?','The differences in standard of living for the richest and poorest people in the world.'],
 ['What is a sweatshop?','A workplace where workers work in harsh or unfair conditions for long hours for little pay.'],
 ['What is fast fashion?','Clothing made with cheap materials in sweatshops, often in LICs exploiting cheap labour.'],
 ['What is aid?','Money, resources or expertise to help in an emergency or for long-term development.'],
 ['What is fair trade?','It ensures producers get a fair and consistent price for their product.'],
 ['What is microfinance?','Small loans to help groups set up a business in their community and earn income.'],
 ['What are SDGs?','17 goals set out by the UN to solve global problems.'],
 ['What is debt relief?','Lowering or cancelling the debt owed by LICs to HICs so money can be directed to development.'],
 ['What is appropriate technology?','Small-scale, low-technology solutions to problems that the community can use.']
];
export const questions = [
 {q:'What is development?',o:['The improvement in wealth, education and health in a country over time','The movement of goods globally','A type of trade tax','A workplace'],a:0,e:'This is the definition in the revision organiser.'},
 {q:'Which is a development indicator?',o:['Literacy rate','Favourite sport','Clothing style','Number of cars in a film'],a:0,e:'Literacy rate is listed as a development indicator.'},
 {q:'What does GDP per capita refer to?',o:['A country’s total population','GDP divided per person','The number of schools','A trade agreement'],a:1,e:'GDP per capita is one of the key development terms in the organiser.'},
 {q:'Which sector includes farming?',o:['Primary','Secondary','Tertiary','Quaternary'],a:0,e:'The primary sector includes extracting raw materials and farming.'},
 {q:'Which sector is associated with manufacturing?',o:['Primary','Secondary','Tertiary','Quaternary'],a:1,e:'The secondary sector involves manufacturing.'},
 {q:'Which sector provides services?',o:['Primary','Secondary','Tertiary','Quaternary'],a:2,e:'The tertiary sector provides services.'},
 {q:'Which is a physical cause of poverty in the source?',o:['Corruption','Debt','Relief','Conflict'],a:2,e:'Relief is listed under physical causes.'},
 {q:'Why can being landlocked contribute to poverty?',o:['It can make access to sea-based trade difficult','It increases literacy automatically','It removes all debt','It guarantees investment'],a:0,e:'The source says a landlocked country can struggle to access sea-based trade.'},
 {q:'Which is an economic cause of poverty?',o:['Climate','Debt','Relief','Colonisation'],a:1,e:'Debt is listed under economic causes.'},
 {q:'How can corruption affect development?',o:['Money may not be spent on developing the country','It guarantees fair trade','It removes conflict','It improves soil quality'],a:0,e:'The source says money may not be spent on developing the country.'},
 {q:'Which is a historic cause of poverty?',o:['Climate','Relief','Conflict','Landlocked location'],a:2,e:'Conflict is listed under historic causes.'},
 {q:'What is aid?',o:['A small business tax','Money, resources or expertise to help development','A type of sweatshop','A development indicator'],a:1,e:'Aid can support emergencies or long-term development.'},
 {q:'What does fair trade aim to ensure?',o:['A fair and consistent price for producers','Longer working hours','Higher debt','Less education'],a:0,e:'This is the definition in the revision organiser.'},
 {q:'What is microfinance?',o:['A large national tax','Small loans to help groups start a business','A type of climate','A trade tariff'],a:1,e:'Microfinance provides small loans for community businesses.'},
 {q:'What is investment?',o:['Funding for essential services and industry','A type of poverty indicator','A historic conflict','A low literacy rate'],a:0,e:'Investment means essential services receive funding; industry investment can create jobs.'},
 {q:'What are SDGs?',o:['Seven trade sectors','17 goals set out by the UN to solve global problems','A type of debt','A type of sweatshop'],a:1,e:'The source defines SDGs as 17 UN goals.'},
 {q:'What is debt relief?',o:['Increasing debt','Lowering or cancelling debt owed by LICs to HICs','A type of factory','A climate pattern'],a:1,e:'Debt relief can free money to be directed to development.'},
 {q:'What is appropriate technology?',o:['Expensive technology only experts can use','Small-scale, low-technology solutions the community can use','A global supply chain','A type of tax'],a:1,e:'This is the source definition.'},
 {q:'What is a sweatshop?',o:['A fair-trade shop','A workplace with harsh or unfair conditions, long hours and little pay','A school','A development indicator'],a:1,e:'This is the definition in the revision organiser.'},
 {q:'What is fast fashion associated with in the source?',o:['Cheap materials and exploited cheap labour','Debt relief','Microfinance','Improved literacy'],a:0,e:'The source links fast fashion with cheap materials, sweatshops and cheap labour.'}
];
